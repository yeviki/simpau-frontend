import { createRouter, createWebHistory } from "vue-router";

import LoginPage from "../pages/LoginPage.vue";
import DashboardLayout from "../layouts/DashboardLayout.vue";
import UsersPage from "../pages/UsersPage.vue";

const routes = [
  // Redirect ke login
  { path: "/", redirect: "/login" },

  // Login route
  {
    path: "/login",
    name: "login",
    component: LoginPage,
    meta: { guest: true },
  },

  // Protected routes
  {
    path: "/",
    component: DashboardLayout,
    meta: { requiresAuth: true },
    children: [
      {
        path: "dashboard",
        name: "dashboard",
        component: () => import("../pages/DashboardHome.vue"),
      },
      {
        path: "users",
        name: "users",
        component: UsersPage,
      },
    ],
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

// Auth middleware
router.beforeEach((to, from, next) => {
  const token = localStorage.getItem("token");

  if (to.meta.requiresAuth && !token) {
    return next("/login");
  }

  if (to.meta.guest && token) {
    return next("/dashboard");
  }

  next();
});

export default router;
