<template>
  <DashboardLayout>
    <div class="flex justify-between mb-4">
      <h1 class="text-2xl font-bold">Users</h1>

      <button
        @click="openAdd"
        class="bg-blue-600 text-white px-4 py-2 rounded"
      >
        Tambah User
      </button>
    </div>

    <!-- Table -->
    <table class="w-full bg-white shadow rounded overflow-hidden">
      <thead class="bg-gray-200">
        <tr>
          <th class="p-3 text-left">ID</th>
          <th class="p-3 text-left">Username</th>
          <th class="p-3 text-left">Email</th>
          <th class="p-3 text-left">Role</th>
          <th class="p-3 text-center">Aksi</th>
        </tr>
      </thead>

      <tbody>
        <tr
          v-for="u in users"
          :key="u.id"
          class="border-b"
        >
          <td class="p-3">{{ u.id }}</td>
          <td class="p-3">{{ u.username }}</td>
          <td class="p-3">{{ u.email }}</td>
          <td class="p-3">{{ u.role }}</td>

          <td class="p-3 space-x-3 text-center">
            <button
              @click="openEdit(u)"
              class="text-blue-600"
            >
              Edit
            </button>

            <button
              @click="remove(u.id)"
              class="text-red-600"
            >
              Delete
            </button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Modal -->
    <Modal
      v-if="showModal"
      @close="showModal = false"
    >
      <template #title>
        {{ isEdit ? "Edit User" : "Tambah User" }}
      </template>

      <div class="space-y-3">
        <input
          v-model="form.username"
          placeholder="Username"
          class="w-full p-2 border rounded"
        />

        <input
          v-model="form.email"
          placeholder="Email"
          class="w-full p-2 border rounded"
        />

        <input
          v-if="!isEdit"
          v-model="form.password"
          placeholder="Password"
          type="password"
          class="w-full p-2 border rounded"
        />

        <select
          v-model="form.role"
          class="w-full p-2 border rounded"
        >
          <option value="adminsuper">Admin Super</option>
          <option value="adminlocal">Admin Local</option>
          <option value="pimpinan">Pimpinan</option>
        </select>
      </div>

      <template #footer>
        <button
          @click="save"
          class="bg-blue-600 text-white px-4 py-2 rounded"
        >
          Simpan
        </button>
      </template>
    </Modal>
  </DashboardLayout>
</template>

<script setup>
import { ref, onMounted } from "vue";
import api from "../api/axios.js";
import DashboardLayout from "../layouts/DashboardLayout.vue";
import Modal from "../components/Modal.vue";

const users = ref([]);
const showModal = ref(false);
const isEdit = ref(false);

const form = ref({
  id: null,
  username: "",
  email: "",
  password: "",
  role: "adminlocal",
});

// Load data users
const loadUsers = async () => {
  const res = await api.get("/users");
  users.value = res.data;
};

// Open tambah user
const openAdd = () => {
  isEdit.value = false;
  form.value = {
    id: null,
    username: "",
    email: "",
    password: "",
    role: "adminlocal",
  };
  showModal.value = true;
};

// Open edit user
const openEdit = (u) => {
  isEdit.value = true;
  form.value = { ...u };
  showModal.value = true;
};

// Save user (add/update)
const save = async () => {
  if (isEdit.value) {
    await api.put(`/users/${form.value.id}`, form.value);
  } else {
    await api.post("/users", form.value);
  }

  showModal.value = false;
  loadUsers();
};

// Delete user
const remove = async (id) => {
  if (confirm("Hapus user ini?")) {
    await api.delete(`/users/${id}`);
    loadUsers();
  }
};

// Load on page open
onMounted(loadUsers);
</script>
