<template>
  <DashboardLayout>
    <h2 class="text-2xl font-bold mb-4">Dashboard Overview</h2>

    <!-- Statistik + Chart + lainnya -->
  </DashboardLayout>
</template>

<script setup>
import DashboardLayout from "../layouts/DashboardLayout.vue";
</script>
