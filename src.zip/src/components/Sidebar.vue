<template>
  <aside
    :class="[
      'h-screen border-r backdrop-blur-xl shadow-xl transition-all duration-300',
      theme === 'dark'
        ? 'bg-white/10 border-white/10'
        : 'bg-white border-gray-200',
      collapsed ? 'w-20' : 'w-64'
    ]"
  >

    <!-- Logo -->
    <div class="flex items-center gap-3 p-6 border-b"
         :class="theme === 'dark' ? 'border-white/10' : 'border-gray-200'">
      <div class="w-10 h-10 bg-blue-600 rounded-xl shadow-lg"></div>
      <h2 v-if="!collapsed" class="text-2xl font-semibold">My Admin</h2>
    </div>

    <!-- Menu (Dari Props) -->
    <nav class="mt-4 space-y-2">
      <RouterLink
        v-for="item in menu"
        :key="item.path"
        :to="item.path"
        class="flex items-center gap-3 px-6 py-3 rounded-lg transition hover:bg-blue-600/20"
        :class="active(item.path)"
      >
        <component :is="item.icon" />
        <span v-if="!collapsed">{{ item.label }}</span>
      </RouterLink>
    </nav>

    <!-- Bottom Buttons -->
    <div class="absolute bottom-4 w-full flex flex-col gap-3 px-4">
      <button @click="$emit('toggleTheme')" class="btn-glass w-full">
        <Sun v-if="theme==='light'" />
        <Moon v-else />
      </button>

      <button @click="$emit('toggleCollapse')" class="btn-glass w-full">
        <ChevronLeft v-if="!collapsed" />
        <ChevronRight v-else />
      </button>
    </div>

  </aside>
</template>

<script setup>
import { useRoute } from "vue-router";
import { Sun, Moon, ChevronLeft, ChevronRight } from "lucide-vue-next";

const props = defineProps({
  collapsed: Boolean,
  theme: String,
  menu: Array
});

const route = useRoute();

const active = (path) =>
  route.path === path
    ? "bg-blue-600/30 text-blue-300 font-semibold"
    : "";
</script>
