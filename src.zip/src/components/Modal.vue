<template>
  <div
    class="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50
           transition-opacity duration-200 animate-fadeIn"
  >
    <div
      class="relative bg-white/10 border border-white/20 backdrop-blur-xl p-6 rounded-2xl shadow-2xl w-96
             animate-scaleIn"
    >
      <!-- Close Button -->
      <button
        @click="$emit('close')"
        class="absolute top-3 right-3 text-white/60 hover:text-white transition"
      >
        ✕
      </button>

      <!-- Title Slot -->
      <h2 class="text-2xl font-semibold text-white mb-4 tracking-wide">
        <slot name="title" />
      </h2>

      <!-- Body Slot -->
      <div class="text-gray-100">
        <slot />
      </div>

      <!-- Footer Slot -->
      <div class="text-right mt-6">
        <slot name="footer" />
      </div>
    </div>
  </div>
</template>

<style scoped>
@keyframes fadeIn {
  from { opacity: 0 }
  to   { opacity: 1 }
}
.animate-fadeIn {
  animation: fadeIn 0.25s ease-out;
}

@keyframes scaleIn {
  0% { opacity: 0; transform: scale(0.9); }
  100% { opacity: 1; transform: scale(1); }
}
.animate-scaleIn {
  animation: scaleIn 0.25s ease-out;
}
</style>
