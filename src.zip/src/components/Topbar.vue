<template>
  <header
    class="p-4 flex justify-between items-center backdrop-blur-xl border-b shadow-lg"
    :class="theme === 'dark'
      ? 'bg-white/10 border-white/10'
      : 'bg-white border-gray-200'"
  >
    <h1 class="text-xl font-semibold tracking-wide flex items-center gap-2">
      <LayoutDashboard />
      Dashboard
    </h1>

    <button
      @click="$emit('logout')"
      class="px-4 py-2 rounded-lg bg-red-500/20 text-red-300 hover:bg-red-500/30 transition-all"
    >
      Logout
    </button>
  </header>
</template>

<script setup>
import { LayoutDashboard } from "lucide-vue-next";
defineProps({ theme: String });
</script>
